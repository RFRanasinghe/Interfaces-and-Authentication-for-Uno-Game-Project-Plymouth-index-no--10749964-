package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class playwithfriendsInt : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_playwithfriends_int)
    }
}