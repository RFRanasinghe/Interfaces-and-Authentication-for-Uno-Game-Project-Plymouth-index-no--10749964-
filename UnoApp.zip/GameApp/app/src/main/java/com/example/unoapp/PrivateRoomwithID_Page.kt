package com.example.unoapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class PrivateRoomwithID_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_private_roomwith_id_page)

        val pressbutton1=findViewById<ImageButton>(R.id.imageButton7)
        pressbutton1.setOnClickListener{
            val Intent= Intent(this,playwithfriendsInt::class.java)
            startActivity(Intent)
        }
    }
}