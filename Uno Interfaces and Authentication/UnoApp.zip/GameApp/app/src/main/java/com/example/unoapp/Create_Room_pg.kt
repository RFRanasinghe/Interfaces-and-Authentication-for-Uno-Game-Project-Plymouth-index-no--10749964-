package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Create_Room_pg : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_room_pg)
    }
}