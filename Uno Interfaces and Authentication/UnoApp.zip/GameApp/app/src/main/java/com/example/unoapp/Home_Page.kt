package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Home_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page)
    }
}