package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class PrivateRoomwithID_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_private_roomwith_id_page)
    }
}