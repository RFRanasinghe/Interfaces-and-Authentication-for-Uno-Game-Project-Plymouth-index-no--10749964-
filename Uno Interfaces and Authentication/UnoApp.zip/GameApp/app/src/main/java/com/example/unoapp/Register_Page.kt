package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.google.android.gms.common.api.internal.RegisterListenerMethod
import com.google.firebase.auth.FirebaseAuthRegistrar
import com.google.firebase.auth.ktx.FirebaseAuthKtxRegistrar
import com.google.firebase.ktx.Firebase

class Register_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_page)

        val btn_click_me = findViewById(R.id.imageView2) as ImageView;
// set on-click listener
        btn_click_me.setOnClickListener {
           // Firebase.makeText(this@Register_Page, "You clicked me.", Firebase.LENGTH_SHORT).show()
        }
    }
}