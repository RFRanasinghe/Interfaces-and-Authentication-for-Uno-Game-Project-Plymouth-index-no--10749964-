package com.example.unoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ScheduleGame_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule_game_page)
    }
}